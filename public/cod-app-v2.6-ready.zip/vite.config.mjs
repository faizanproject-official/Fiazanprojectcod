import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  root: 'web/admin',
  plugins: [react()],
  build: {
    outDir: '../../server/public/admin',
    emptyOutDir: true,
  },
});
